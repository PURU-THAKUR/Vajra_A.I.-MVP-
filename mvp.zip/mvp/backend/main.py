import time
from sensors.process_monitor import collect_process_data
from ai_core.feature_extractor import extract_features
from ai_core.baseline_builder import build_baseline
from ai_core.anomaly_detector import train_model, detect_anomaly
from ai_core.threat_classifier import classify, get_attack_type
from ai_core.explainability import explain
from decision_engine.decision_engine import decide
from backend.event_writer import write_event

print("[Vajra AI] Live detection engine started")

# ---- INITIAL BASELINE ----
process_data = collect_process_data()
features = extract_features(process_data)
baseline = build_baseline(features)
model = train_model(baseline)

# ---- CONTINUOUS LIVE LOOP ----
while True:
    try:
        process_data = collect_process_data()
        features = extract_features(process_data)

        scores = detect_anomaly(features)

        for score in scores:
            threat = classify(score)
            attack_type = get_attack_type(threat, score)
            decision = decide(threat)
            explanation = explain(score, attack_type)

            write_event(
                threat_level=threat,
                attack_type=attack_type,
                decision=decision,
                explanation=explanation,
                score=score,
                source="REAL"
            )

        time.sleep(5)

    except Exception as e:
        print("[ERROR]", e)
        time.sleep(5)
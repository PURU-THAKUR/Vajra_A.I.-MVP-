import json
import time
from pathlib import Path

EVENT_FILE = Path("data/processed/events.json")

def write_event(threat_level, attack_type, decision, explanation, score, source="REAL"):
    EVENT_FILE.parent.mkdir(parents=True, exist_ok=True)

    event = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "threat_level": threat_level,
        "attack_type": attack_type,
        "decision": decision,
        "confidence": explanation["confidence"],
        "reason": explanation["reason"],
        "score": float(score),
        "source": source
    }

    events = []
    if EVENT_FILE.exists():
        with open(EVENT_FILE, "r") as f:
            events = json.load(f)

    events.append(event)

    with open(EVENT_FILE, "w") as f:
        json.dump(events, f, indent=2)
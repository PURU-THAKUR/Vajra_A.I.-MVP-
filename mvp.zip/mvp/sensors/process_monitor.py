import psutil
import time

def collect_process_data():
    data = []
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
        try:
            data.append(proc.info)
        except psutil.NoSuchProcess:
            continue
    return data

if __name__ == "__main__":
    while True:
        print(collect_process_data())
        time.sleep(5)
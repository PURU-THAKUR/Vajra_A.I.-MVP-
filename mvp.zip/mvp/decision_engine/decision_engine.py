def decide(threat_level):
    if threat_level in ["CRITICAL", "HIGH"]:
        return "ALERT"
    if threat_level == "SUSPICIOUS":
        return "LOG"
    return "IGNORE"
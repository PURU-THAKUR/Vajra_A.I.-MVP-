import streamlit as st
import json
import pandas as pd
from pathlib import Path
from streamlit_autorefresh import st_autorefresh

# Page configuration (should be at the very top)
st.set_page_config(layout="wide", page_title="Live Threat Dashboard")

st.title("Vajra AI — Live Threat Intelligence")

EVENT_FILE = Path("data/processed/events.json")

# Auto refresh
refresh_interval = 5000  # milliseconds (5 seconds)
st_autorefresh(interval=refresh_interval, key="vajra_refresh")

# Check if file exists first
if not EVENT_FILE.exists():
    st.warning("No live threats detected yet.")
    st.info("Waiting for threat data...")
    
    # Show only metrics with default values
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Events", 0)
    col2.metric("Critical", 0)
    col3.metric("High", 0)
    col4.metric("Live Feed", "ON")
    
    st.stop()

try:
    # Read and parse the events file
    with open(EVENT_FILE) as f:
        content = f.read().strip()
        
        if not content:  # Check if file is empty
            st.warning("Threat file is empty. No threats detected.")
            
            # Show metrics with zeros
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Total Events", 0)
            col2.metric("Critical", 0)
            col3.metric("High", 0)
            col4.metric("Live Feed", "ON")
            st.stop()
            
        events = json.loads(content)
        
        if not events:  # Check if JSON is empty list
            st.warning("No threat events found in the data.")
            
            # Show metrics with zeros
            col1, col2, col3, col4 = st.columns(4)
            col1.metric("Total Events", 0)
            col2.metric("Critical", 0)
            col3.metric("High", 0)
            col4.metric("Live Feed", "ON")
            st.stop()
            
        df = pd.DataFrame(events)
        
        # Ensure required columns exist
        required_columns = ["threat_level", "score"]
        for col in required_columns:
            if col not in df.columns:
                df[col] = 0 if col == "score" else "UNKNOWN"
        
        # ---- METRICS ----
        col1, col2, col3, col4 = st.columns(4)
        
        critical_count = 0
        high_count = 0
        
        if "threat_level" in df.columns:
            critical_count = (df["threat_level"] == "CRITICAL").sum()
            high_count = (df["threat_level"] == "HIGH").sum()
        
        col1.metric("Total Events", len(df))
        col2.metric("Critical", critical_count)
        col3.metric("High", high_count)
        col4.metric("Live Feed", "ON")
        
        # ---- LIVE GRAPH ----
        st.subheader("Risk Score Timeline")
        if "score" in df.columns and len(df) > 0:
            st.line_chart(df["score"])
        else:
            st.info("No score data available for chart")
        
        # ---- LIVE TABLE ----
        st.subheader("Live Threat Feed")
        display_columns = ["timestamp", "threat_level", "attack_type", "decision", "confidence", "source"]
        
        # Filter to only existing columns
        available_columns = [col for col in display_columns if col in df.columns]
        
        if available_columns and len(df) > 0:
            st.dataframe(
                df[available_columns],
                use_container_width=True
            )
        else:
            st.info("No threat data available for display")
        
        # ---- EXPLAINABILITY ----
        if len(df) > 0:
            st.subheader("AI Explainability (Latest Event)")
            latest = df.iloc[-1]
            
            explain_data = {
                "Threat Level": latest.get("threat_level", "UNKNOWN"),
                "Attack Type": latest.get("attack_type", "UNKNOWN"),
                "Decision": latest.get("decision", "UNKNOWN"),
                "Confidence": latest.get("confidence", 0),
                "Reason": latest.get("reason", "No reason provided"),
                "Data Source": latest.get("source", "UNKNOWN")
            }
            st.json(explain_data)
        else:
            st.subheader("AI Explainability")
            st.info("No events available for explainability")
            
except json.JSONDecodeError:
    st.error("Error: Invalid JSON format in events file")
    st.stop()
except Exception as e:
    st.error(f"Error loading threat data: {str(e)}")
    st.stop()
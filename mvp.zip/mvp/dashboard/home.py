import streamlit as st

st.set_page_config(page_title="Vajra AI", layout="wide")

# ---- HEADER ----
st.markdown("""
# Vajra AI
### Intelligent Cyber Threat Detection System
""")

st.markdown("""
Vajra AI is an **AI-powered cyber intelligence engine** that continuously monitors your system,
detects suspicious behavior in real time, and explains **what is happening and why**.
""")

st.divider()

# ---- KEY CAPABILITIES ----
st.subheader("What Vajra AI Does")

col1, col2, col3 = st.columns(3)

with col1:
    st.info("""
    **Live Threat Detection**
    - Monitors running processes  
    - Detects abnormal behavior  
    - Flags ongoing attacks
    """)

with col2:
    st.warning("""
    **Attack Understanding**
    - Identifies attack category  
    - Measures risk level  
    - Explains why it is dangerous
    """)

with col3:
    st.success("""
    **Decision Intelligence**
    - Alert recommendations  
    - No false panic  
    - Human-in-the-loop
    """)

st.divider()

# ---- ATTACK TYPES ----
st.subheader("Attack Categories Vajra AI Detects")

attack_col1, attack_col2, attack_col3, attack_col4 = st.columns(4)

attack_col1.metric("Privilege Escalation", "y")
attack_col2.metric("Malware-like Activity", "y")
attack_col3.metric("Insider / Scripted Attacks", "y")
attack_col4.metric("USB-based Threats", "y")

st.caption("Detection is behavior-based, not signature-based.")

st.divider()

# ---- SYSTEM STATUS ----
st.subheader(" Current System Status")

status_col1, status_col2, status_col3 = st.columns(3)

status_col1.metric("System Monitoring", "ACTIVE ")
status_col2.metric("Threat Engine", "RUNNING ")
status_col3.metric("Last Scan", "Live")

st.divider()

# ---- NAVIGATION ----
st.subheader("Continue")

st.markdown("""
Click below to view **live threat intelligence** detected by Vajra AI.
""")

if st.button("Open Live Threat Dashboard"):
    st.switch_page("pages/Live_Threat_Dashboard.py")
    st.switch_page("pages/Live_Threat_Dashboard.py")
    # Add parent directory to path to import modules

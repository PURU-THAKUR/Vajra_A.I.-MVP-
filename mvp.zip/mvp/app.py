# app.py
import streamlit as st
import psutil
import joblib
import numpy as np
from datetime import datetime
import time

# -----------------------------
# Configuration
# -----------------------------
MODEL_FILE = "vajra_model.pkl"
REFRESH_INTERVAL = 3
ANOMALY_THRESHOLD = 5

# -----------------------------
# Load Model
# -----------------------------
model = joblib.load(MODEL_FILE)

# -----------------------------
# Streamlit Session State (CRITICAL)
# -----------------------------
if "anomaly_count" not in st.session_state:
    st.session_state.anomaly_count = 0

if "retrain_required" not in st.session_state:
    st.session_state.retrain_required = False

# -----------------------------
# Feature Extraction
# -----------------------------
def get_live_features():
    return np.array([[
        psutil.cpu_percent(interval=0.5),
        psutil.virtual_memory().percent,
        len(psutil.pids()),
        psutil.net_io_counters().bytes_sent,
        psutil.disk_io_counters().write_bytes
    ]])

# -----------------------------
# UI Setup
# -----------------------------
st.set_page_config(page_title="Vajra AI – Live Monitor", layout="wide")
st.title("🛡 Vajra AI – Live Behavioral Intelligence")
st.caption("Real-time monitoring with decision-gated AI retraining")

# -----------------------------
# Data + Prediction
# -----------------------------
features = get_live_features()

cpu = features[0][0]
ram = features[0][1]
processes = features[0][2]
net_out = features[0][3]
disk_write = features[0][4]

prediction = model.predict(features)[0]

# -----------------------------
# Decision Logic
# -----------------------------
if prediction == -1:
    st.session_state.anomaly_count += 1
else:
    st.session_state.anomaly_count = 0

if st.session_state.anomaly_count >= ANOMALY_THRESHOLD:
    st.session_state.retrain_required = True

# -----------------------------
# Risk Assessment
# -----------------------------
risk_score = 90 if prediction == -1 else 10

st.subheader("📊 Live Risk Assessment")
st.metric("Behavioral Risk Score", risk_score)

# -----------------------------
# Threat Verdict
# -----------------------------
st.subheader("🚨 Threat Status")

if st.session_state.retrain_required:
    st.error("Training required — repeated anomaly pattern confirmed")
elif prediction == -1:
    st.warning(
        f"Anomalous behavior detected "
        f"({st.session_state.anomaly_count}/{ANOMALY_THRESHOLD})"
    )
else:
    st.success("System behavior normal — baseline monitoring")

# -----------------------------
# Live System Telemetry (FIXED)
# -----------------------------
st.subheader("🖥 Live System Telemetry")

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("CPU Usage (%)", round(cpu, 2))
    st.metric("Active Processes", int(processes))

with col2:
    st.metric("Memory Usage (%)", round(ram, 2))
    st.metric("Disk Writes (MB)", int(disk_write / 1e6))

with col3:
    st.metric("Outbound Network (MB)", int(net_out / 1e6))

# -----------------------------
# AI Internal State (TRANSPARENCY)
# -----------------------------
st.subheader("🧠 AI Internal State")

st.write("Model Type:", "Isolation Forest (Unsupervised)")
st.write("Learning Mode:", "Decision-Gated Secure Retraining")
st.write("Anomaly Counter:", st.session_state.anomaly_count)
st.write("Retraining Required:", st.session_state.retrain_required)

# -----------------------------
# Footer + Auto Refresh
# -----------------------------
st.caption(f"Last updated: {datetime.now().strftime('%H:%M:%S')}")

time.sleep(REFRESH_INTERVAL)
st.rerun()
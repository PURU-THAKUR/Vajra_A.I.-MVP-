import psutil
import csv
import time
import joblib
from sklearn.ensemble import IsolationForest

LOG_FILE = "behavior_log.csv"
MODEL_FILE = "vajra_model.pkl"
SAMPLE_INTERVAL = 3
TRAINING_SAMPLES = 500  # ~25 minutes

def collect_data():
    with open(LOG_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["cpu", "memory", "processes", "bytes_sent", "disk_write"])

        for _ in range(TRAINING_SAMPLES):
            writer.writerow([
                psutil.cpu_percent(interval=0.5),
                psutil.virtual_memory().percent,
                len(psutil.pids()),
                psutil.net_io_counters().bytes_sent,
                psutil.disk_io_counters().write_bytes
            ])
            time.sleep(SAMPLE_INTERVAL)

def train_model():
    data = []
    with open(LOG_FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            data.append([float(x) for x in row])

    model = IsolationForest(
        contamination=0.05,
        random_state=42
    )
    model.fit(data)
    joblib.dump(model, MODEL_FILE)

if __name__ == "__main__":
    print("Collecting behavior data...")
    collect_data()
    print("Training Vajra AI model...")
    train_model()
    print("Training complete. Model saved.")
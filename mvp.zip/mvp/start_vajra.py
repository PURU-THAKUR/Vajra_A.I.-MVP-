# start_vajra.py
import subprocess
import sys
import os
import time

print("🚀 Vajra AI - Complete System Launcher")
print("=" * 50)

# Define all services
services = [
    {
        "name": "Backend API",
        "cmd": [sys.executable, "backend/main.py"],
        "port": 5000,
        "url": "http://localhost:5000"
    },
    {
        "name": "Main Dashboard",
        "cmd": [sys.executable, "-m", "streamlit", "run", "dashboard/home.py", 
                "--server.port", "8501", "--server.headless", "true"],
        "port": 8501,
        "url": "http://localhost:8501"
    },
    {
        "name": "AI Monitor",
        "cmd": [sys.executable, "-m", "streamlit", "run", "app.py",
                "--server.port", "8502", "--server.headless", "true"],
        "port": 8502,
        "url": "http://localhost:8502"
    },
    {
        "name": "Live Threat",
        "cmd": [sys.executable, "-m", "streamlit", "run", 
                "dashboard/pages/Live_Threat_Dashboard.py",
                "--server.port", "8503", "--server.headless", "true"],
        "port": 8503,
        "url": "http://localhost:8503"
    }
]

# Start all services
processes = []
for service in services:
    print(f"\n▶️ Starting {service['name']}...")
    try:
        # For Windows, use CREATE_NEW_CONSOLE to keep windows open
        if os.name == 'nt':  # Windows
            import subprocess
            proc = subprocess.Popen(
                service["cmd"],
                creationflags=subprocess.CREATE_NEW_CONSOLE
            )
        else:  # Linux/Mac
            proc = subprocess.Popen(service["cmd"])
        
        processes.append(proc)
        print(f"   ✅ Started: {service['url']}")
        time.sleep(2)  # Give time for each to start
    except Exception as e:
        print(f"   ❌ Failed: {e}")

# Print summary
print("\n" + "=" * 50)
print("🎉 ALL SERVICES STARTED SUCCESSFULLY!")
print("=" * 50)
for service in services:
    print(f"• {service['name']}: {service['url']}")

print("\n📋 Quick Access:")
print("1. Dashboard: http://localhost:8501")
print("2. AI Monitor: http://localhost:8502") 
print("3. Live Threats: http://localhost:8503")
print("4. Backend API: http://localhost:5000")

print("\n🛑 To stop all: Close all opened windows or press Ctrl+C in each terminal")
print("=" * 50)

# Keep running
try:
    input("\nPress Enter to stop all services...")
    print("\nShutting down all services...")
    for proc in processes:
        proc.terminate()
except KeyboardInterrupt:
    print("\nShutting down...")
    for proc in processes:
        proc.terminate()
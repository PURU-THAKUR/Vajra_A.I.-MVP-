# main_app.py - ERROR FREE VERSION
import streamlit as st
import time
import os
import sys
import pandas as pd
import numpy as np
from datetime import datetime

# ==================== AI ENGINE ====================
def load_ai_model():
    """Load AI model without errors"""
    try:
        import joblib
        if os.path.exists("vajra_model.pkl"):
            return joblib.load("vajra_model.pkl")
        return None
    except:
        return None

def get_system_metrics():
    """Get real system metrics with error handling"""
    try:
        import psutil
        return {
            'cpu': psutil.cpu_percent(interval=0.1),  # Reduced interval
            'memory': psutil.virtual_memory().percent,
            'processes': len(psutil.pids()),
            'network': psutil.net_io_counters().bytes_sent,
            'disk': psutil.disk_io_counters().write_bytes,
            'time': datetime.now().strftime("%H:%M:%S")
        }
    except:
        # Return demo data if psutil fails
        import random
        return {
            'cpu': random.uniform(20, 80),
            'memory': random.uniform(40, 90),
            'processes': random.randint(100, 200),
            'network': random.randint(1000, 10000),
            'disk': random.randint(1000, 10000),
            'time': datetime.now().strftime("%H:%M:%S")
        }

# ==================== BACKEND SERVICES (ERROR FREE) ====================
def start_backend_services():
    """Start services without assuming specific classes"""
    services = []
    
    # Check sensors module
    if os.path.exists("sensors/"):
        sensor_files = [f for f in os.listdir("sensors") if f.endswith('.py')]
        if sensor_files:
            services.append(("Sensors", "✅ Ready"))
        else:
            services.append(("Sensors", "⚠️ No .py files"))
    else:
        services.append(("Sensors", "❌ Not found"))
    
    # Check decision engine
    if os.path.exists("decision_engine/"):
        de_files = [f for f in os.listdir("decision_engine") if f.endswith('.py')]
        if de_files:
            services.append(("Decision Engine", "✅ Ready"))
        else:
            services.append(("Decision Engine", "⚠️ No .py files"))
    else:
        services.append(("Decision Engine", "❌ Not found"))
    
    # Check AI core
    if os.path.exists("ai_core/"):
        ai_files = [f for f in os.listdir("ai_core") if f.endswith('.py')]
        if ai_files:
            services.append(("AI Core", f"✅ {len(ai_files)} modules"))
        else:
            services.append(("AI Core", "⚠️ No .py files"))
    else:
        services.append(("AI Core", "❌ Not found"))
    
    # Check backend
    if os.path.exists("backend/"):
        backend_files = [f for f in os.listdir("backend") if f.endswith('.py')]
        if backend_files:
            services.append(("Backend", f"✅ {len(backend_files)} services"))
        else:
            services.append(("Backend", "⚠️ No .py files"))
    else:
        services.append(("Backend", "❌ Not found"))
    
    return services

# ==================== THREAT DETECTION ====================
def detect_threats(metrics, ai_model):
    """Simple threat detection"""
    threats = []
    
    # Simple rule-based detection (No AI dependency)
    if metrics['cpu'] > 85:
        threats.append({
            'timestamp': metrics['time'],
            'type': 'High CPU Usage',
            'level': 'HIGH' if metrics['cpu'] > 90 else 'MEDIUM',
            'source': f"CPU:{metrics['cpu']:.1f}%",
            'confidence': 90 if metrics['cpu'] > 90 else 70,
            'action': 'Investigate'
        })
    
    if metrics['memory'] > 85:
        threats.append({
            'timestamp': metrics['time'],
            'type': 'High Memory Usage',
            'level': 'HIGH' if metrics['memory'] > 90 else 'MEDIUM',
            'source': f"Memory:{metrics['memory']:.1f}%",
            'confidence': 85,
            'action': 'Monitor'
        })
    
    # AI-based detection if model exists
    if ai_model:
        try:
            features = np.array([[
                metrics['cpu'],
                metrics['memory'],
                metrics['processes'],
                metrics['network'],
                metrics['disk']
            ]])
            
            prediction = ai_model.predict(features)[0]
            
            if prediction == -1 and len(threats) == 0:
                threats.append({
                    'timestamp': metrics['time'],
                    'type': 'Behavioral Anomaly',
                    'level': 'MEDIUM',
                    'source': 'AI Detection',
                    'confidence': 75,
                    'action': 'Review'
                })
        except:
            pass
    
    return threats

# ==================== STREAMLIT APP ====================
st.set_page_config(
    page_title="Vajra AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'page' not in st.session_state:
    st.session_state.page = "Dashboard"
if 'ai_model' not in st.session_state:
    st.session_state.ai_model = load_ai_model()
if 'threats' not in st.session_state:
    st.session_state.threats = []
if 'metrics_history' not in st.session_state:
    st.session_state.metrics_history = []
if 'services' not in st.session_state:
    st.session_state.services = start_backend_services()

# ==================== SIDEBAR ====================
with st.sidebar:
    st.title("🛡️ Vajra AI")
    st.markdown("---")
    
    # Navigation
    page = st.radio(
        "Navigate to:",
        ["Dashboard", "AI Monitor", "Live Threats", "Modules", "Settings"],
        key="nav_radio"
    )
    
    st.session_state.page = page
    
    st.markdown("---")
    
    # Real-time Metrics
    st.subheader("Live Metrics")
    
    metrics = get_system_metrics()
    
    col1, col2 = st.columns(2)
    with col1:
        # CPU with color coding
        cpu = metrics['cpu']
        if cpu < 60:
            color = "🟢"
        elif cpu < 80:
            color = "🟡"
        else:
            color = "🔴"
        st.metric("CPU", f"{cpu:.1f}%", delta=color)
    
    with col2:
        # Memory with color coding
        mem = metrics['memory']
        if mem < 60:
            color = "🟢"
        elif mem < 80:
            color = "🟡"
        else:
            color = "🔴"
        st.metric("Memory", f"{mem:.1f}%", delta=color)
    
    # AI Status
    st.markdown("---")
    st.subheader("AI Status")
    
    if st.session_state.ai_model:
        st.success("✅ Model Loaded")
        # Test prediction
        try:
            test_features = np.array([[metrics['cpu'], metrics['memory'], metrics['processes'], 0, 0]])
            prediction = st.session_state.ai_model.predict(test_features)[0]
            status = "⚠️ Anomaly" if prediction == -1 else "✅ Normal"
            st.caption(f"Status: {status}")
        except:
            st.caption("Status: Ready")
    else:
        st.error("❌ Model Missing")
        st.caption("Using rule-based detection")

# ==================== DASHBOARD PAGE ====================
if st.session_state.page == "Dashboard":
    st.title("🛡️ Vajra AI Dashboard")
    st.caption("Real-time Security Monitoring")
    
    # Get current metrics
    metrics = get_system_metrics()
    
    # Add to history (keep last 20)
    st.session_state.metrics_history.append(metrics)
    if len(st.session_state.metrics_history) > 20:
        st.session_state.metrics_history = st.session_state.metrics_history[-20:]
    
    # Top Row Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("CPU Usage", f"{metrics['cpu']:.1f}%", 
                 delta=f"{'↑' if metrics['cpu'] > 50 else '↓'} live")
    
    with col2:
        st.metric("Memory Usage", f"{metrics['memory']:.1f}%",
                 delta=f"{'↑' if metrics['memory'] > 50 else '↓'} live")
    
    with col3:
        st.metric("Processes", metrics['processes'])
    
    with col4:
        threats = detect_threats(metrics, st.session_state.ai_model)
        st.metric("Active Threats", len(threats))
    
    st.divider()
    
    # Middle Row - Charts
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 CPU & Memory Trend")
        if len(st.session_state.metrics_history) > 1:
            history_df = pd.DataFrame(st.session_state.metrics_history)
            chart_data = pd.DataFrame({
                'CPU': history_df['cpu'],
                'Memory': history_df['memory']
            })
            st.line_chart(chart_data)
        else:
            st.info("Collecting data...")
    
    with col2:
        st.subheader("🚨 Threat Detection")
        current_threats = detect_threats(metrics, st.session_state.ai_model)
        
        if current_threats:
            for threat in current_threats[-3:]:  # Show last 3 threats
                if threat['level'] == 'HIGH':
                    st.error(f"🔴 {threat['type']} - {threat['source']}")
                elif threat['level'] == 'MEDIUM':
                    st.warning(f"🟡 {threat['type']} - {threat['source']}")
                else:
                    st.info(f"🟢 {threat['type']} - {threat['source']}")
        else:
            st.success("✅ No active threats")
            st.caption("System operating normally")
    
    st.divider()
    
    # Bottom Row - Quick Actions
    st.subheader("⚡ Quick Actions")
    
    action_col1, action_col2, action_col3 = st.columns(3)
    
    with action_col1:
        if st.button("🔍 Run System Scan", use_container_width=True):
            with st.spinner("Scanning..."):
                time.sleep(2)
                st.toast("Scan complete!", icon="✅")
    
    with action_col2:
        if st.button("📊 View Detailed Logs", use_container_width=True):
            st.session_state.page = "Live Threats"
            st.rerun()
    
    with action_col3:
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.rerun()

# ==================== AI MONITOR PAGE ====================
elif st.session_state.page == "AI Monitor":
    st.title("🤖 AI Behavior Monitor")
    
    metrics = get_system_metrics()
    
    # AI Prediction
    if st.session_state.ai_model:
        try:
            features = np.array([[
                metrics['cpu'],
                metrics['memory'],
                metrics['processes'],
                metrics['network'],
                metrics['disk']
            ]])
            
            prediction = st.session_state.ai_model.predict(features)[0]
            probability = st.session_state.ai_model.score_samples(features)[0]
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("AI Prediction")
                if prediction == -1:
                    st.error("🚨 ANOMALY DETECTED")
                    st.metric("Risk Score", 85)
                else:
                    st.success("✅ NORMAL BEHAVIOR")
                    st.metric("Risk Score", 15)
            
            with col2:
                st.subheader("Confidence")
                confidence = abs(probability) * 100
                st.metric("Confidence Level", f"{confidence:.1f}%")
                
                # Progress bar
                st.progress(min(confidence/100, 1.0))
            
            # Feature Importance
            st.subheader("Feature Analysis")
            
            feature_cols = st.columns(5)
            features_data = [
                ("CPU", metrics['cpu'], 80),
                ("Memory", metrics['memory'], 80),
                ("Processes", metrics['processes'], 150),
                ("Network", metrics['network']/1e6, 10),
                ("Disk", metrics['disk']/1e6, 10)
            ]
            
            for idx, (name, value, threshold) in enumerate(features_data):
                with feature_cols[idx]:
                    st.metric(name, f"{value:.1f}" if idx < 3 else f"{value:.2f}MB")
                    if value > threshold:
                        st.warning("⚠️ High")
                    else:
                        st.success("✅ Normal")
        
        except Exception as e:
            st.error(f"AI Error: {str(e)}")
            st.info("Showing basic metrics instead")
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("CPU", f"{metrics['cpu']:.1f}%")
                st.metric("Memory", f"{metrics['memory']:.1f}%")
            with col2:
                st.metric("Processes", metrics['processes'])
                st.metric("Status", "Basic Mode")
    else:
        st.error("AI Model Not Available")
        st.info("Please ensure vajra_model.pkl exists in the root folder")

# ==================== LIVE THREATS PAGE ====================
elif st.session_state.page == "Live Threats":
    st.title("🚨 Live Threat Intelligence")
    
    # Generate or load threats
    metrics = get_system_metrics()
    new_threats = detect_threats(metrics, st.session_state.ai_model)
    
    # Add new threats to session state
    for threat in new_threats:
        if threat not in st.session_state.threats:
            st.session_state.threats.append(threat)
    
    # Keep only last 50 threats
    if len(st.session_state.threats) > 50:
        st.session_state.threats = st.session_state.threats[-50:]
    
    # Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    total_threats = len(st.session_state.threats)
    high_threats = len([t for t in st.session_state.threats if t['level'] == 'HIGH'])
    med_threats = len([t for t in st.session_state.threats if t['level'] == 'MEDIUM'])
    
    with col1:
        st.metric("Total Threats", total_threats)
    with col2:
        st.metric("High Severity", high_threats)
    with col3:
        st.metric("Medium Severity", med_threats)
    with col4:
        st.metric("Latest", st.session_state.threats[-1]['timestamp'] if st.session_state.threats else "None")
    
    # Threats Table
    if st.session_state.threats:
        st.subheader("Threat Timeline")
        
        # Convert to DataFrame for display
        threats_df = pd.DataFrame(st.session_state.threats)
        
        # Display table
        st.dataframe(
            threats_df[['timestamp', 'type', 'level', 'source', 'action']],
            use_container_width=True,
            hide_index=True
        )
        
        # Latest threat detail
        if len(st.session_state.threats) > 0:
            st.subheader("Latest Threat Analysis")
            latest = st.session_state.threats[-1]
            
            detail_col1, detail_col2 = st.columns(2)
            
            with detail_col1:
                st.write(f"**Timestamp:** {latest['timestamp']}")
                st.write(f"**Type:** {latest['type']}")
                st.write(f"**Level:** {latest['level']}")
            
            with detail_col2:
                st.write(f"**Source:** {latest['source']}")
                st.write(f"**Confidence:** {latest.get('confidence', 'N/A')}%")
                st.write(f"**Action:** {latest['action']}")
    else:
        st.success("✅ No threats detected")
        st.info("System is operating normally")
    
    # Clear threats button
    if st.button("🧹 Clear Threat History"):
        st.session_state.threats = []
        st.success("Threat history cleared!")
        time.sleep(1)
        st.rerun()

# ==================== MODULES PAGE ====================
elif st.session_state.page == "Modules":
    st.title("📦 System Modules")
    
    st.subheader("Module Status")
    
    for service, status in st.session_state.services:
        col1, col2 = st.columns([1, 4])
        with col1:
            if "✅" in status:
                st.success("✅")
            elif "⚠️" in status:
                st.warning("⚠️")
            else:
                st.error("❌")
        with col2:
            st.write(f"**{service}** - {status}")
    
    st.divider()
    
    # Module Details
    st.subheader("Module Details")
    
    modules = [
        ("ai_core/", "AI Core Engine", "Behavior analysis, threat classification"),
        ("sensors/", "Sensor System", "Process monitoring, file watching"),
        ("decision_engine/", "Decision Engine", "Automated response decisions"),
        ("backend/", "Backend Services", "Data storage, API endpoints"),
        ("dashboard/", "Dashboard", "User interface, visualization"),
    ]
    
    for path, name, description in modules:
        with st.expander(f"{name}"):
            st.write(description)
            
            if os.path.exists(path):
                files = [f for f in os.listdir(path) if f.endswith('.py')]
                if files:
                    st.write("**Files:**")
                    for file in files:
                        st.code(file)
                else:
                    st.warning("No Python files found")
            else:
                st.error("Directory not found")

# ==================== SETTINGS PAGE ====================
elif st.session_state.page == "Settings":
    st.title("⚙️ System Configuration")
    
    tab1, tab2, tab3 = st.tabs(["Detection", "Display", "System"])
    
    with tab1:
        st.subheader("Detection Settings")
        
        sensitivity = st.slider("Detection Sensitivity", 1, 10, 7)
        st.caption(f"Current: Level {sensitivity}")
        
        auto_scan = st.checkbox("Auto-scan every 5 minutes", value=True)
        alert_level = st.selectbox("Alert Level", ["HIGH Only", "MEDIUM & HIGH", "ALL"])
        
        if st.button("💾 Save Detection Settings"):
            st.success("Settings saved!")
    
    with tab2:
        st.subheader("Display Settings")
        
        refresh_rate = st.slider("Refresh Rate (seconds)", 1, 30, 5)
        st.caption(f"Page refreshes every {refresh_rate} seconds")
        
        theme = st.selectbox("Theme", ["Dark", "Light", "System"])
        show_details = st.checkbox("Show detailed metrics", value=True)
        
        if st.button("💾 Save Display Settings"):
            st.success("Display settings saved!")
    
    with tab3:
        st.subheader("System Settings")
        
        st.write("**System Information**")
        st.write(f"Python: {sys.version.split()[0]}")
        st.write(f"Working Directory: {os.getcwd()}")
        
        st.divider()
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Test AI Model", use_container_width=True):
                if st.session_state.ai_model:
                    st.success("AI Model is working!")
                else:
                    st.error("AI Model not found")
        
        with col2:
            if st.button("🧹 Clear Cache", use_container_width=True):
                st.session_state.metrics_history = []
                st.session_state.threats = []
                st.success("Cache cleared!")

# ==================== FOOTER ====================
st.divider()
footer_col1, footer_col2, footer_col3 = st.columns([2, 1, 1])

with footer_col1:
    st.caption(f"🛡️ Vajra AI | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

with footer_col2:
    st.caption(f"CPU: {metrics['cpu']:.1f}%")

with footer_col3:
    if len(st.session_state.threats) > 0:
        st.caption(f"Threats: {len(st.session_state.threats)}")
    else:
        st.caption("✅ All clear")

# ==================== AUTO REFRESH ====================
# Only auto-refresh Dashboard and Live Threats pages
if st.session_state.page in ["Dashboard", "Live Threats"]:
    time.sleep(5)  # Refresh every 5 seconds
    st.rerun()
elif st.session_state.page == "AI Monitor":
    time.sleep(3)  # Refresh every 3 seconds for AI Monitor
    st.rerun()
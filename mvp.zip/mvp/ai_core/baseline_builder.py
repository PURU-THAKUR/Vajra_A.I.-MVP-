from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

def build_baseline(features):
    return scaler.fit_transform(features)
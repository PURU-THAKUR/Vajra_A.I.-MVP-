def classify(score):
    if score < -0.25:
        return "CRITICAL"
    elif score < -0.15:
        return "HIGH"
    elif score < -0.05:
        return "SUSPICIOUS"
    return "NORMAL"


def get_attack_type(threat, score):
    if threat == "CRITICAL":
        return "Malware-like Activity"
    if threat == "HIGH":
        return "Privilege Escalation / Suspicious Process"
    if threat == "SUSPICIOUS":
        return "Automated or Insider Activity"
    return "Normal Behavior"
def explain(score, attack_type):
    return {
        "reason": f"Detected behavior matches pattern of {attack_type}",
        "confidence": round(abs(score), 2)
    }
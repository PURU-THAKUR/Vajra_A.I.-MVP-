import numpy as np

def extract_features(process_data):
    features = []
    for proc in process_data:
        features.append([
            proc.get("cpu_percent", 0),
            proc.get("memory_percent", 0)
        ])
    return np.array(features)
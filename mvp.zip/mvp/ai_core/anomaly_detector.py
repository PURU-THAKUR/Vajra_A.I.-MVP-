from sklearn.ensemble import IsolationForest

model = IsolationForest(contamination=0.05)

def train_model(data):
    model.fit(data)
    return model

def detect_anomaly(data):
    scores = model.decision_function(data)
    return scores